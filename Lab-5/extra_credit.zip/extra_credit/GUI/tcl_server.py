from __future__ import print_function
from subprocess import Popen
from time import sleep
from sys import exit
import socket

# Server parameters
host = 'localhost'
port = 2540

# Specifies whether reading or writing
Read_Instr = 0
Write_Instr = 1


def toBin(x, size):
    """Helper function to convert integer to a bitstring of a given size"""
    return bin(x).lstrip('0b').zfill(size)


class TclServer(object):
    def __init__(self, quartus_cmd):
        self.is_running = False
        self.quartus_cmd = quartus_cmd
        self.data = None

    def __del__(self):
        self.close_server()

    def _init_tcl_server(self):
        """Initializes tcl server by uses quartus to run tcl script"""
        quartus_args = [self.quartus_cmd, '-t', 'TCL_Server.tcl']
        print('Running comand: ', ' '.join(quartus_args))
        self.tcl = Popen(quartus_args, shell=True)

    def start_server(self):
        """Starts a tcl server that communicates with the vjtag instance on the fpga"""
        # from the button call
        if (not self.is_running):

            # AF_INET creates an IPV4 address family # SOCK_STREAM connections is TCP protocol
            self.conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.conn.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.conn.bind((host, port))

            self._init_tcl_server()
            # self.tcl = subprocess.Popen('start /B Start_Server.LNK', shell=True) #opens the TCL Server and the Quartus TCL

            sleep(1)
            self.conn = self.Probe_Port(host, port)
            sleep(1)

            self.is_running = True  # This is a flag that when set lets other functions know that there is a connection to the board

    def close_server(self):
        """Closes the tcl server if its running"""
        if (not self.is_running):
            pass
        else:
            self.is_running = False
            self.tcl.kill()
            self.conn.close()

    def Probe_Port(self, host, port):
        """Connects to the server"""
        # AF_INET creates an IPV4 address family
        # SOCK_STREAM connections is TCP protocol
        try:
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as msg:
            exit();
        while True:
            try:
                self.s.connect((host, port))
                break
            except OSError as e:
                print("Problem with connecting to device, retrying\n")
        return self.s

    def writeCommand(self, inputAddr, inputData):
        """Writes to the vjtag glue logic"""
        wr = toBin(int(Write_Instr), 1)
        addr = toBin(int(inputAddr), 16)
        data = toBin(int(inputData), 15)
        self.writeOut(data + addr + wr)

    def readCommand(self, inputAddr):
        """Reads from the vjtag glue logic"""
        wr = toBin(int(Read_Instr), 1)
        addr = toBin(int(inputAddr), 16)
        data = toBin(int(0), 15)
        self.writeOut(data + addr + wr)
        return int(self.data.decode('utf-8'), 2)

    def writeOut(self, val):
        """Encodes the data sent via the TCL server to the vJtag"""
        if (self.is_running):
            # This will take an integer input and convert it to a binary string.
            # It will also cut off the 0b at the beginning of the string.
            self.conn.send(val.encode('utf-8') + b'\n')  # Newline is required to flush the buffer on the Tcl server
            self.data = self.conn.recv(
                32 + 2)  # This will always need to have two additional bits added to the size of the string, this is for a start and stop bit.
        else:
            pass
