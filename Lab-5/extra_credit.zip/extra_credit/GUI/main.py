from __future__ import print_function

import os
import time

# To handle Python 2 vs 3 differences in using the Tkinter package
try:
    from Tkinter import *
    from ttk import *
except ImportError:
    from tkinter import *
    from tkinter.ttk import *

from errorHand import * #checkInputs
from tcl_server import TclServer

Go_Addr     = 0
Input1_Addr = 1
Input2_Addr = 2
Result_Addr = 3
Done_Addr   = 4

class App(Frame):
    def __init__(self, master, exec_cmd):
        self.master = master
        self.server = TclServer(exec_cmd)
        Frame.__init__(self, master, relief=SUNKEN, bd=0)
        self.start()

    def start(self):
        # Create the left frame
        self.buttonWidth =14
        self.master.title("DE0 GCD Calculator")
        self.master.resizable(0, 0)
        self.leftFrame = Frame(self.master)
        self.leftFrame.pack(side=LEFT, fill=Y)
        
        # create the setup frame
        self.SetupFrame = LabelFrame(self.leftFrame, text="Setup", pady=10, padx=10)
        self.SetupFrame.pack(fill=BOTH)
        
        # create the Input frame
        self.InputFrame = LabelFrame(self.leftFrame, text="Input", pady=10, padx=10)
        self.InputFrame.pack(fill=BOTH)
        
        # create the Operation frame
        self.CalcFrame = LabelFrame(self.leftFrame, text="Operations", pady=10, padx=10)
        self.CalcFrame.pack(fill=BOTH)

        # Create the connection Button - this button will establish the connection to the TCL server
        self.connectButton = Button(self.SetupFrame, text="Connect" , command=lambda: self.server.start_server())
        self.connectButton.config(  width = self.buttonWidth )
        self.connectButton.grid(row=0, column=0, sticky  = W, padx=10)
        
        # Create the deconnect Button - this button will terminate the connection to the TCL server
        self.DisconnectButton = Button(self.SetupFrame, text="Disconnect",command=lambda: self.server.close_server())
        self.DisconnectButton.config(  width = self.buttonWidth )
        self.DisconnectButton.grid(row=0, column=3, sticky = W,padx=10)
        
        self.input1_label = Label(self.InputFrame, text ="Input1")
        self.input1_label.grid(row =0, sticky = E)

        self.input2_label = Label(self.InputFrame, text ="Input2")
        self.input2_label.grid(row =1)

        # create the Entry textbox for Input1
        self.Input1_Entry = Entry(self.InputFrame)
        self.Input1_Entry.grid(row=0,column=1, sticky = E)
        
        # create the Entry textbox for Input2
        self.Input2_Entry = Entry(self.InputFrame)
        self.Input2_Entry.grid(row=1,column=1)

        # Create the "Calculate GCD" Button
        self.Calculate_GCD_Button = Button(self.CalcFrame, text="Calculate GCD" )
        self.Calculate_GCD_Button.config(  width = self.buttonWidth )
        self.Calculate_GCD_Button.grid(row=0, column=0, sticky  = W, padx=10)
        self.Calculate_GCD_Button.bind("<Button-1>", lambda event, x=0: self.sendData(event, x))

        # Create the "Clear Button
        self.ClearButton = Button(self.CalcFrame, text="Clear" )
        self.ClearButton.config(  width = self.buttonWidth )
        self.ClearButton.grid(row=0, column=1, sticky  = W, padx=10)
        self.ClearButton.bind("<Button-1>", lambda event, x=0: self.Clear_treeView())

        # create the right frame
        self.tree = Treeview()
        self.tree["columns"] = ("Inputs","Results")
        self.tree["show"] = "headings"
        self.tree.column("Inputs", width = 200)
        self.tree.column("Results", width = 200)
        self.tree.heading("Inputs", text = "Inputs")
        self.tree.heading("Results", text = "Results")

        self.tree.pack()    


    # Clear the treeView
    def Clear_treeView(self):
       for i in self.tree.get_children():
              self.tree.delete(i)

    def sendData(self, event, array_location):
        if not self.server.is_running:
            noConn = Toplevel()
            noConn.title("No Connection")
            msg = Label(noConn, text='There is no connection established to the DE0 board')
            msg.pack()
            button = Button(noConn, text='close', command=noConn.destroy)
            button.pack()
        else:

            # Sanitize Use Inputs to program requirements
            Input1_Data = self.Input1_Entry.get()
            Input2_Data = self.Input2_Entry.get()
            if checkInputs(Input1_Data, Input2_Data) == 1:
                pass
            else:
                # sending Input 1 & 2
                self.server.writeCommand(Input1_Addr, Input1_Data)
                self.server.writeCommand(Input2_Addr, Input2_Data)

                # sending the "Go =1 " signal
                self.server.writeCommand(Go_Addr, 1)

                # wait on the "Done" signal
                resultPane = self.tree.insert("", 0, text="", values=(
                "GCD( " + self.Input1_Entry.get() + " , " + self.Input2_Entry.get() + " ) = ",
                "Done signal not received"))

                timeout = time.time() + 3  # times out in 5 seconds
                isTimeOut = False
                while self.server.readCommand(Done_Addr) == 0:
                    if time.time() > timeout:
                        isTimeOut = True
                        break
                    time.sleep(1)

                if not isTimeOut:
                    self.server.readCommand(Result_Addr)
                    self.tree.item(resultPane, text="", values=(
                    "GCD( " + self.Input1_Entry.get() + " , " + self.Input2_Entry.get() + " ) = ",
                    int(self.server.data.decode('utf-8'), 2)))

                # sending the "Go = 0" signal
                    self.server.writeCommand(Go_Addr, 0)

###############################################################################
def quartus_exists(check_cmd):

    import os, subprocess
    
    stdout = open(os.devnull, 'w')
    r = subprocess.call(check_cmd, shell = True, stdout = stdout, stderr = stdout)
    stdout.close()
        
    if r != 0: return False
    
    return True

def get_quartus_exec(path=None):

    if os.name == 'nt':
        check_cmd = 'where \q quartus_stp'
        base_cmd = 'quartus_stp.exe'
    else:
        check_cmd = 'type quartus_stp'
        base_cmd = 'quartus_stp'

    quartus_exec_cmd = None
    if path:
        print('Using provided path to find quartus executable...')
        quartus_exec_path = os.path.join(path, base_cmd)
        if os.path.isfile(quartus_exec_path):
            quartus_exec_cmd = quartus_exec_path
        else:
            print('Cannot find quartus_stp executable from given path!')
    else:
        print('Using path environment variable to find quartus executable...')
        if quartus_exists(check_cmd):
            quartus_exec_cmd = base_cmd
        else:
            print('Cannot find quartus_stp executable from path variable!')
    return quartus_exec_cmd

def main():
    #logging.basicConfi(level=logging.INFO)  #enable logging
    exec_cmd = None
    if len(sys.argv) > 2:
        print('Usage: {} [<path to quartus bin folder>]'.format(sys.argv[0]))
        sys.exit()
    elif len(sys.argv) == 2:
        exec_cmd = get_quartus_exec(sys.argv[1])
    elif len(sys.argv) == 1:
        exec_cmd = get_quartus_exec()

    if exec_cmd is None:
        sys.exit()

    root = Tk()
    app = App(root, exec_cmd)
    root.mainloop()


if __name__ =='__main__':
    main()
